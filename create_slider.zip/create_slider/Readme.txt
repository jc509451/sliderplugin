Plugin Name: Create Slider
Plugin Creator: Ridham Pravinchandra Nagralawala
About Plugin: A Plugin to create a slider for multiple images on any page.

How it will work :
You need to add a shortcode for this plugin to work on any page:
1) Copy plaugin and paste it into the plugin folder of the website.
2) Open Wordpress dashboard->appearance->plugins->create_slider->activate.

Shortcode of Plugin:

[custom_slider url="image_url,image_url,image_url"].