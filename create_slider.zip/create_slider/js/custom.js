        jQuery(document).ready(function(){
            jQuery(".carousel-inner .item:first-child").addClass('active');
            jQuery(".carousel-indicators li:first-child").addClass('active');
        });